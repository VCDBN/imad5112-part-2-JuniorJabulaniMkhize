package com.varsitycollege.st10087432

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.absoluteValue
import kotlin.math.sqrt


class MainActivity : AppCompatActivity() {
    @SuppressLint("SetTextI18n")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val numberEditText1: EditText = findViewById(R.id.editTextNumber)
        val numberEditText2: EditText = findViewById(R.id.editTextNumber2)
        val resultEditText: EditText = findViewById(R.id.editTextNumber3)

        val addButton: Button = findViewById(R.id.button5)
        val subtractButton: Button = findViewById(R.id.button6)
        val multiplyButton: Button = findViewById(R.id.button7)
        val divideButton: Button = findViewById(R.id.button8)

        addButton.setOnClickListener {
            val num1 = numberEditText1.text.toString().toDoubleOrNull() ?: 0.0
            val num2 = numberEditText2.text.toString().toDoubleOrNull() ?: 0.0
            val result = num1 + num2
            resultEditText.setText("Sum: $num1 + $num2 = $result")        }

        subtractButton.setOnClickListener {
            val num1 = numberEditText1.text.toString().toDoubleOrNull() ?: 0.0
            val num2 = numberEditText2.text.toString().toDoubleOrNull() ?: 0.0
            val result = num1 - num2
            resultEditText.setText("Difference: $num1 - $num2 = $result")        }

        multiplyButton.setOnClickListener {
            val num1 = numberEditText1.text.toString().toDoubleOrNull() ?: 0.0
            val num2 = numberEditText2.text.toString().toDoubleOrNull() ?: 0.0
            val result = num1 * num2
            resultEditText.setText("Product: $num1 * $num2 = $result")    // Your existing code for multiplication
        }

        divideButton.setOnClickListener {
            val num1 = numberEditText1.text.toString().toDoubleOrNull() ?: 0.0
            val num2 = numberEditText2.text.toString().toDoubleOrNull() ?: 1.0

            if (num2 == 0.0) {
                resultEditText.setText("Error: Division by zero")
            } else {
                val result = num1 / num2
                resultEditText.setText("Quotient: $num1 / $num2 = $result")
            }
        }

        // New functionality for square root and power calculations
        val sqrtButton: Button = findViewById(R.id.button9)
        val powerButton: Button = findViewById(R.id.button10)

        sqrtButton.setOnClickListener {
            val num1 = numberEditText1.text.toString().toDoubleOrNull() ?: 0.0

            if (num1 < 0) {
                val result = sqrt(num1.absoluteValue)
                resultEditText.setText("Square Root: sqrt($num1) = $result i")
            } else {
                val result = sqrt(num1)
                resultEditText.setText("Square Root: sqrt($num1) = $result")
            }
        }

        powerButton.setOnClickListener {
            val num1 = numberEditText1.text.toString().toDoubleOrNull() ?: 0.0
            val num2 = numberEditText2.text.toString().toDoubleOrNull() ?: 1.0

            var result = 1.0
            for (i in 1..num2.toInt()) {
                result *= num1
            }

            resultEditText.setText("$num1^$num2 = $result")
        }
    }
}

